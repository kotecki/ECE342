%% Matlab m-file for ECE342
% ECE 342 Lab 2 - 3-stage MFBP Filter Sensitivity Analysis

%% Set variables and filenames
addpath('/users/Kotecki/CppSim/CppSimShared/HspiceToolbox');    % ngspice boolbox
format long;        
clear variables;
hspc_filename = sprintf('Lab2_sa.hspc');       % hspc filename
digilent_filename = sprintf('Lab2x.csv');    % digilent csv filename

%% initialize variables
cfmax = 0; dbmax = 0; bwmax = 0;
cfmin = 1e6; dbmin = 200; bwmin = 1e6;

c_n = 1e-9;         % capacitance nominal value
%r1_n = 1e3;
r1_n = 936;         % r1 nominal value
r2_n = 65e3;        % r2 nominal value
tolerance_r = 0.05/2;   % set 5% 2-sigma resistor tolerance
tolerance_c = 0.10/2;   % set 10% 2-sigma capacitor tolerance

iter = input('number of iterations = ');
%tolerance = input('tolerance = ');

%% Plot Vout as a function of frequency
fs = 16;    % font size
lw = 3;   % linewidth
F1 = figure('Name', '3-stage MFBP', 'Position', [200, 75, 850, 600]);   % figure size and location

%% establish while loop

loop_test = 1;
while 1
    
%% component parameters

var = randn *tolerance_c; c1 = c_n*(1+var);
var = randn *tolerance_c; c2 = c_n*(1+var);
var = randn *tolerance_c; c3 = c_n*(1+var);
var = randn *tolerance_c; c4 = c_n*(1+var);
var = randn *tolerance_c; c5 = c_n*(1+var);
var = randn *tolerance_c; c6 = c_n*(1+var);
var = randn *tolerance_r; r1 = r1_n*(1+var);
var = randn *tolerance_r; r2 = r2_n*(1+var);
var = randn *tolerance_r; r3 = r1_n*(1+var);
var = randn *tolerance_r; r4 = r2_n*(1+var);
var = randn *tolerance_r; r5 = r1_n*(1+var);
var = randn *tolerance_r; r6 = r2_n*(1+var);

if loop_test == 1
    c1 = c_n; c2 = c_n; c3 = c_n; c4 = c_n; c5 = c_n; c6 = c_n;
    r1 = r1_n; r3 = r1_n; r5 = r1_n;
    r2 = r2_n; r4 = r2_n; r6 = r2_n;
end

%% simulate
hspc_set_param('r1', r1, hspc_filename);    % write parameter r1 to hspc file
hspc_set_param('r2', r2, hspc_filename);    % write parameter r2 to hspc file
hspc_set_param('r3', r3, hspc_filename);    % write parameter r3 to hspc file
hspc_set_param('r4', r4, hspc_filename);    % write parameter r4 to hspc file
hspc_set_param('r5', r5, hspc_filename);    % write parameter r5 to hspc file
hspc_set_param('r6', r6, hspc_filename);    % write parameter r6 to hspc file
hspc_set_param('c1', c1, hspc_filename);    % write parameter c1 to hspc file
hspc_set_param('c2', c2, hspc_filename);    % write parameter c2 to hspc file
hspc_set_param('c3', c3, hspc_filename);    % write parameter c3 to hspc file
hspc_set_param('c4', c4, hspc_filename);    % write parameter c4 to hspc file
hspc_set_param('c5', c5, hspc_filename);    % write parameter c5 to hspc file
hspc_set_param('c6', c6, hspc_filename);    % write parameter c6 to hspc file

hspc_addline('.ac dec 1000 100 1e6', hspc_filename);    % write analysis type to hspc file
ngsim(hspc_filename);   % run ngspice

%% Load simulation results and extract time and vout1 and vout2
simdata = loadsig('simrun.raw');
sim_freq = evalsig(simdata, 'FREQUENCY');
sim_Vout = evalsig(simdata,'vout');
% read CSV file
% measdata = csvread(digilent_filename, 9);
% meas_freq = measdata(:,1);
% meas_vdb = measdata(:,2);

%% plot
if loop_test ~= 1
    lw = .7*lw;
end
semilogx(sim_freq, 20*log10(abs(sim_Vout)), 'linewidth',lw);
grid on;    % add grid
set(gca, 'fontsize', fs);   % increase font size
ylabel('Gain (dB)', 'fontsize', fs);        % y-axis label
xlabel('Frequency (Hz)', 'fontsize', fs);   % x-axis label
title('3-Stage MFBP Filter')                % figure title
hold on

%% Calculate graph info and write to graph - simulated results
[Vm, Fm_index] = max(abs(sim_Vout));    % maximum value of Vout and index location
Fp = sim_freq(Fm_index);                % frequency at peak
Vdb = 20*log10(abs(sim_Vout));          % Vout in dB
Vdb_max = max(Vdb);                     % Vout max in dB
% calculate 3-dB bandwidth
for index = 1: length(Vdb)
    if Vdb(index) > Vdb_max - 3
        bw1 = sim_freq(index);
        break
    end
end
for index = Fm_index: length(Vdb)
    if Vdb(index) < Vdb_max -3
        bw2 = sim_freq(index);
        break
    end
end
bw = bw2 - bw1;

if Vdb_max < dbmin
    dbmin = Vdb_max;
end
if Vdb_max > dbmax
    dbmax = Vdb_max;
end

if Fp < cfmin
    cfmin = Fp;
end
if Fp > cfmax
    cfmax = Fp;
end

if bw < bwmin
    bwmin = bw;
end
if bw > bwmax
    bwmax = bw;
end

%% test for end of loop
if loop_test == iter
    break
end
loop_test = loop_test + 1;
end

% print information to graph
t0 = sprintf('Simulated gain with %0.3g%% resistor tolerance \n', tolerance_r*200);
t1 = sprintf('Min Fp = %0.4g kHz, Max Fp = %0.4g kHz \n', cfmin/1000, cfmax/1000);
t2 = sprintf('Min Gain = %0.3g dB, Max Gain = %0.3g dB \n', dbmin, dbmax);
t3 = sprintf('Min BW = %0.3g kHz, Max BW = %0.3g kHz', bwmin/1000, bwmax/1000 );
text = [t0, t1 t2 t3];
dim = [.15 .7 .2 .2];
annotation('textbox', dim, 'String', text, 'FitBoxToText', 'on', 'BackgroundColor', 'white', 'FaceAlpha', 0.8, 'fontsize', 16);

%% end of M file
